"""
Temporary external grading policy for LCA 2021

CANCELED ... It will be too confusing.
It is easier to just use num_tol2

* numtol2 is rigid, but reliable for any case.
    It cannot handle eng prefix.
* Peeraphol's AutolabJudge can handle prefix nicely,
but it works unpredictable in its "equation" mode (inc. express with function, e.g., exp or cos)

That is,
* For cases AutolabJudge can handle, e.g.,
    Q1.1. Vrms = 5 V
    Q1.2. Irms = 0.04 A
Use AutolabJudge
* For cases AutolabJudge reliability is in doubt, e.g.,
    Q2.1. -10 + Vx - 100 ix = 0
    Q2.2. v(t) = -10 exp( -500 t) + 30 V
    Q2.3. i(t) = 0.01 cos( 677 t + 1.57 ) A
    Q2.4. Vx = 3 angle 1.57 V

"""