"""
Miscellaneuos tools
Created Apr 18th, 2021
"""

def pack_message(txt):
    """
    Turn a text with '\n' or '\r' and ' ' into a corresponding text without '\n', '\r', or ' '.
    """
    packed = txt.replace("\r", "\n")
    packed = packed.replace("\n", "\\n")
    packed = packed.replace(" ", "[sp]")

    return packed
# end pack_message

def unpack_message(packed):
    unpacked = packed.replace("[sp]", " ")
    unpacked = unpacked.replace("\\n", "\n")
    return unpacked

if __name__ == '__main__':
    txt = """line1 has some words.
line2 is not much different.
Line 3 I start to have nothing to say."""

    print(txt)

    print("\nPacked to:\n", pack_message(txt))
