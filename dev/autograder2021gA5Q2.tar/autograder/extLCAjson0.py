"""
Apr 15th, 2021.
Modified from extLCAjson1.py to temporarily get something,
since Peeraphol's AutolabJudge seems to have troubles with Q3.ans and Q4.ans.

That is, extLCAjson0.py is almost identical to extLCAjson1.py,
but it calls numtol_policy2, instead of AutolabJudge.grading.

Calling
    python extLCAjson0.py student.ans Q3 ./answers/Q3.ans 0.01 60 HidNum
    python extLCAjson0.py <student json> <Q#> <reference> <tol> <score> <report>
"""

import sys
from base_policies import clean_newline, trim_ending
#from LCA_Judge.src import AutolabJudge as Judge
from policy2021 import numtol_policy2

from emform_tools import read_form

if __name__ == '__main__':

    policy_par = {}

    # Begin Debug/Default Block
    policy_par["policy"] = "extLCAjson1"
    policy_par["student"] = "student/student.ans"
    policy_par["Q"] = "Q4"
    policy_par["ref"] = "answers/Q4.ans"
    policy_par["tol"] = "0.01"
    policy_par["score"] = "60"
    policy_par["mode"] = "HidNum"
    # End Debug/Default Block

    # Begin Deployment Block
    var_list = ["policy",   # argv[0]: this policy, e.g., extLCAjson1.py
                "student",  # argv[1]: student's submission, e.g., student.json
                "Q",        # argv[2]: question id, e.g., Q3
                "ref",      # argv[3]: reference text, e.g., answers/Q1.ans
				"tol",      # argv[4]: tolerance, e.g., 0.001
				"score",    # argv[5]: full score, e.g., 60
				"mode"]     # argv[6]: reporting mode, .e.g, Silence, HidNum, Show

    for i, arg in enumerate(sys.argv):
        policy_par[var_list[i]] = arg
    # End Deployment Block

    #==========================
    # Read student's answers
    #==========================

    student = "" # default value

    try:

        student_all = read_form(policy_par["student"])

        if policy_par["Q"] in student_all:
            student = student_all[policy_par["Q"]]
        else:
            print("extLCAjson1: question {} cannot be found in the student's json.".format(policy_par["Q"]))

    except Exception as e:
        print("extLCAjson1: student\'s answers (json) load error:", e)
        print(0, end='')
        exit(0)
    # end try-except

    # Clean texts
    clean_student = clean_newline(student)
    trim_student = trim_ending(clean_student)
    student_ans = trim_student.strip()

    ############################
    # Get the reference answer
    ############################
    with open(policy_par["ref"], encoding='utf-8', mode='r') as f:
        ref = f.read()

    # Clean texts
    clean_ref = clean_newline(ref)
    trim_ref = trim_ending(clean_ref)
    ref_ans = trim_ref.strip()

    # Grade the output confering to reference
    # based on policy: Perapol's AutolabJudge

    student_score = numtol_policy2(student_ans, ref_ans,
        int(policy_par["score"]), policy_par["mode"],
        float(policy_par["tol"]), neg_handling=True)

    print(student_score, end='')

#end main