/*
P4: Motor freight.
*/

#include <iostream>

using namespace std;

int main(){
	
	float ftl = 12, ltl = 0.02;
	
	int option;
	float cost_per_km, weight, distance, cost;

	cout << "(1-full, 0-less): ";
	cin >> option;
	
	if (option == 1) {
		cost_per_km = ftl;
	
	} else {
		cout << "Weight: ";
		cin >> weight;
		cost_per_km = ltl * weight;
				
	}
	
	cout << "Distance: ";
	cin >> distance;
	
	cost = distance * cost_per_km;
	cout << "Cost: " << cost << endl;
	
	
	return 0;
}