#include <iostream>

using namespace std;

int main(){
	
	float c = 3e8;
	float f, lam, L;
	cout << "Frequency: ";
	cin >> f;
	lam = c/f;
	L = lam/4;
	cout << "Length: " << L << endl;
	
	return 0;
}