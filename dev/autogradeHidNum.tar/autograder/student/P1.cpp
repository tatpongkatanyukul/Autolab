/*
P1. Output.
*/

#include <iostream>

using namespace std;

int main(){
	
	cout << "TRUST" << endl;
	return 0;
}