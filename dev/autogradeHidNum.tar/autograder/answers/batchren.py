"""
Batch rename files.
Motivation: rename all P4* to P9*.
"""

import os
import sys

if __name__ == '__main__':
    print('Batch rename files')
    print('!Caution! Work on a copied folder (just in case).')

    src = ''
    des = ''

    if len(sys.argv) > 2:
        src = sys.argv[1]
        des = sys.argv[2]
    else:
        src = input('Part to be changed: ')
        des = input('Change the part to: ')
    # end if

    print('Changing', src, 'in all filenames to', des, '...')
    fnames = [f for f in os.listdir() if src in f]
    for f in fnames:
        print('*', f, end='-->')
        newname = f.replace(src, des)
        os.rename(f, newname)
        print(newname)
        
    print()