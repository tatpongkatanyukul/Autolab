voltage = float(input("Enter voltage (V): "))
current = float(input("Enter current (A): "))

print("The power is", voltage*current, "W")
