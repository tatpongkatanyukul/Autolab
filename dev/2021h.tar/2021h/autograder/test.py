import extDynamicGrader3 as dg


if __name__ == '__main__':
    print(dg.test())