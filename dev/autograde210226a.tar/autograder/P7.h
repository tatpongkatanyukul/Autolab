/*
Header
*/

float cover_price(float printing, float shipping, float retailer, float author);
