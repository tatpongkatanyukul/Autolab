



float search_area(float speed, float time);