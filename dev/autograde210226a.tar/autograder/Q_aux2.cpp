/*
Q_aux1
To: facilitate the question-answer grading.
It reads a file and print out on screen.
*/

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(int argc, char *argv[])
{

    string fname = "Q0.txt";

    if (argc > 1)
    {
        std::string arg1(argv[1]);
        fname = arg1;
        // cout << "fname =" << fname << endl;

    }

    string line;
    ifstream student_file (fname);

    if (student_file.is_open())
    {
		
        while ( getline (student_file, line) )
		{
			cout << line << endl;
		}
		
		//cout << student_file;
		
		student_file.close();
	}

  else {
    return 1;
  }



    return 0;
}
