"""
Verification module version 1 (Sep 16th, 2019).
"""

def verify(id, verf_code, codebook):
    '''
    :param id: string to be verified
    :param verf_code: string of verification code
    :param codebook: function mapping id to correct verf_code
    :return: True/False
    '''

    cvc = codebook(id)

    verf_bool = False
    if cvc is not None:
        verf_bool = (verf_code.strip() == cvc.strip())


    return verf_bool


def codebookf(txtin):
    codefile = 'codebook.txt'

    vcode = None

    with open(codefile, 'r') as f:
        for line in f:
            email, code1, code2 = line.split(',')
            if email.strip() == txtin:
                vcode =  code1.strip() + ' ' + code2.strip()
                break

    return vcode


def read_student_verf(verf_file):

    student_vcode = None
    with open(verf_file, 'r') as f:
        student_vcode = f.read()

    return student_vcode


if __name__ == '__main__':

    # id = 'noone@kku.ac.th'
    # id = 'narisara_ai@kkumail.com'
    # id = 'aon04939@gmail.com'
    id = 'natta_kit@kkumail.com'

    vc = codebookf(id)
    print(vc)
    print(verify(id, vc, codebookf))
    print(verify(id, 'test', codebookf))

    print(read_student_verf('./student/verify.txt'))
    print(verify('jirawat_ku@kkumail.com',
                 read_student_verf('./student/verify.txt'),
                 codebookf))