import re
from numgraders import check_answer

def clean_whitespace(dirty_text):
    clean_text = re.sub(' +', ' ', dirty_text)
    # remove excessive white spaces
    return clean_text


def clean_newline(dirty_text):
    clean_text = re.sub('\r\r', '\r', dirty_text)
    clean_text = re.sub('\r', '\n', clean_text)

    # to be fixed (need to do it in while loop)
    clean_text = re.sub('\n\n', '\n', clean_text)
    clean_text = re.sub('\n\n', '\n', clean_text)
    clean_text = clean_whitespace(clean_text)

    return clean_text

def trim_ending(dirty_text):
    if len(dirty_text) == 0:
        return dirty_text

    clean_text = dirty_text
    if dirty_text[-1] == '\n':
        clean_text = dirty_text[:-1]

    return clean_text



def grading(policy, policy_attrib, test_out, gt_ans,
            full_score, Px, log, mode='Test'):


    # Check file in notepad++ with [view] > [show symbol] > [show all characcters]
    # f = open('debug' + Px + 'out.txt', 'w')
    # f.write(test_out)
    #
    # f = open('debug' + Px + 'gt.txt', 'w')
    # f.write(gt_ans)

    # mode = Test: see details
    # mode = Deploy: no details

    test_score = 0

    if policy == 'numtol':
        # numerical tolerance

        tol = float(policy_attrib)

        # Clean texts
        test_out = clean_newline(test_out)
        test_out = trim_ending(test_out)
        test_out = test_out.strip()

        gt_ans = clean_newline(gt_ans)
        gt_ans = trim_ending(gt_ans)
        gt_ans = gt_ans.strip()

        # Grading test_out c.f. gt_ans
        test_lines = test_out.split('\n')
        gt_lines = gt_ans.split('\n')

        Ng = len(gt_lines)
        Ns = len(test_lines)
        M = min(Ng, Ns)

        print('grader {}: # submitted lines: {}'.format(policy, Ns))
        print('grader {}: # reference lines: {}'.format(policy, Ng))

        point = 0
        for i in range(M):

            if check_answer(test_lines[i], gt_lines[i], tol):
                point += 1

            elif mode == 'Test':
                print('* Line', i, '(First line is Line 0)')
                print('** student:', test_lines[i])
                print('** correct:', gt_lines[i])

        test_score = full_score * point / Ng

    elif policy == 'parline':
        # partial credit by line

        # Clean texts
        test_out = clean_newline(test_out)
        test_out = trim_ending(test_out)
        test_out = test_out.strip()

        gt_ans = clean_newline(gt_ans)
        gt_ans = trim_ending(gt_ans)
        gt_ans = gt_ans.strip()

        # Grading test_out c.f. gt_ans
        test_lines = test_out.split('\n')
        gt_lines = gt_ans.split('\n')

        Ng = len(gt_lines)
        Ns = len(test_lines)
        M = min(Ng, Ns)

        print('grader {}: # submitted lines: {}'.format(policy, Ns))
        print('grader {}: # ground-truth lines: {}'.format(policy, Ng))

        point = 0
        for i in range(M):
            if test_lines[i] == gt_lines[i]:
                point += 1

            if mode == 'Test':
                print('* Correct = ', test_lines[i] == gt_lines[i],
                    '\n** student:', test_lines[i],
                    '\n** correct:', gt_lines[i])

        test_score = full_score * point / Ng

    else: # exact match (no partial credit)
        clean_test = clean_newline(test_out)
        clean_ref = clean_newline(gt_ans)

        # Check file in notepad++ with [view] > [show symbol] > [show all characcters]
        f = open('debug' + Px + 'out.txt', 'w')
        f.write(clean_test)

        f = open('debug' + Px + 'gt.txt', 'w')
        f.write(clean_ref)


        if clean_test == clean_ref:
            test_score = full_score

        if mode == 'Test':
            print('* Exact match score =', test_score)
            print('** student:', clean_test)
            print('** correct:', clean_ref)



    return test_score
