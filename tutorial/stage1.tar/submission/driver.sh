#!/bin/bash

# driver.sh - The simplest autograder we could think of. It checks
#   that students can write a C program that compiles, and then
#   executes with an exit status of zero.
#   Usage: ./driver.sh

# This should be a file I'll run to grade student's program.
# bash ./driver.sh

echo "=========================================="
echo "   driver.sh python3.5 autograder v 2.0"
echo "   Hand over control to python script  "
echo "=========================================="

echo "Extract submission"
(make clean; make)
status=$?
if [ ${status} -ne 0 ]; then
	echo "Failure: Unable to extract the submission"
	echo "{\"scores\": {\"P1\": 0}}"
	exit
fi

echo "Extraction completed."

echo "Run python script ..."

# Run code of each question
# Current directory: submission
# Student's submission: submission/student

output=$(python3.5 grader_center4.py "./answers/ans.txt")
status=$?
if [ ${status} -ne 0 ]; then
	echo "grader_center.py fails."
	echo "* return status = ${status}"
	echo "{\"scores\": {\"P1\": 0}}"
else
	echo "grader_center.py is complete."
	echo "=== grader_center.py output ==="
	echo "${output}"
fi

#Example	   
#echo "{\"scores\": {\"P1\": 10, \"P2\": 10},\"scoreboard\":[10, 10, 20]}"

exit

