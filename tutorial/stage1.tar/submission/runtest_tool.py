import os
from shutil import copy
import subprocess

# For choosing a grading policy
from graders import grading

from cmd_tool import cmd


def clean_folder(target_folder, confirm=True):
    print('Clean folder:', target_folder)

    if confirm:
        c = input('Confirm cleaning [y|n]:')

        if c != 'y':
            print('Cancel cleaning.')
            return

    fs = os.listdir(target_folder)
    for f in fs:
        p = os.path.join(target_folder, f)
        os.remove(p)

    print('cleaning is done.')


def run_grader(directive, runtest_prefix, runtest_suffix, paths):

    student_path = paths['student']
    answer_path = paths['answer']
    working_path = paths['working']
    log_file = paths['log_file']

    # Clear log_file
    with open(log_file, 'w') as f:
        f.write('')

    # Create Grading Table: get grading details from directive file
    Grading_Table = []
    f = open(directive, 'r')
    i = 0
    for line in f:
        if i > 0:
            px, score, student, runtest, runtime, \
            grader, gattrib, report_mode, test_case = line.split('\;')

            ## Allow comment out the line
            if px[0] == '#':
                continue

            clean_tc = test_case
            if clean_tc[-1] == '\n':
                clean_tc = clean_tc[:-1]

            clean_tc = clean_tc.strip()

            d = {'Px':px, 'score': int(score),
                 'student': student.strip(),
                 'runtest': runtest.strip(),
                 'runtime': runtime.strip(),
                 'grader': grader.strip(),
                 'attrib': gattrib.strip(),
                 'report_mode': report_mode.strip(),
                 'test_case': clean_tc.split(',')}

            Grading_Table.append(d)


        i += 1
    f.close()

    #print(Grading_Table)
    print('run_grader: total grading', len(Grading_Table), 'problems')

    graded = {}
    for P in Grading_Table:
        print('\nrun_grader: on', P['Px'])
        student_submission = os.path.join(student_path, P['student'])
        if os.path.exists(student_submission):
            print('run_grader: * %s is submitted'%P['student'])
            print('run_grader: * tested with "%s" using %s policy (attributes: %s)' % (P['runtest'],
                                                        P['grader'], P['attrib']))
            print('run_grader: * test case(s):', P['test_case'])

            # Copy student_submission to current working directory
            copy(student_submission, working_path)

            point = 0
            num_tc = len(P['test_case'])

            for i, tc in enumerate(P['test_case']):

                tc_input, tc_ans = tc.strip().split(' ')
                # print(tc_input)
                # print(tc_ans)

                # Get input stream (or dummy if program requires none)
                f = open(os.path.join(answer_path,tc_input), 'r')
                istream = f.read()
                f.close()

                # Get correct answer
                f = open(os.path.join(answer_path,tc_ans), encoding='utf-8',
                         mode='r')
                ans = f.read()
                f.close()

                # Compile and run the test
                run_complete, rout = \
                    cmd(runtest_prefix,
                        P['runtest'],
                        runtest_suffix,
                        istream, float(P['runtime']))

                # Grade result if run_complete
                if run_complete:

                    tc_score = P['score']/num_tc
                    # print('debug: tc_score = ', tc_score)

                    # Grade the output against the answer

                    grading_out = grading(P['grader'], P['attrib'],
                                    rout, ans, tc_score,
                                    P['Px'], log_file,
                                    mode=P['report_mode'])

                    print('GC: * grading ', grading_out)
                    point += grading_out

            graded[P['Px']] = round(point)

            # Clean up/Remove student file
            print('run_grader: * Done: clean up {}'.format(P['student']))
            try:
                os.remove(P['student'])
            except Exception as e:
                print('** clean up fails: ', e)

        else:
            print('run_grader: * %s is NOT submitted' % P['student'])
            graded[P['Px']] = 0

    # Last line of printing must be score report
    # print(graded)

    csep = ''
    score_txt = '{"scores": {'
    sboard_txt = ''
    total_score = 0
    for P in Grading_Table:
        score_txt += csep + '"%s": %d'%(P['Px'], graded[P['Px']])
        sboard_txt += csep + '%d'%graded[P['Px']]
        total_score += graded[P['Px']]
        if csep == '':
            csep = ', '

    score_txt += '},"scoreboard":[%s, %d]}'%(sboard_txt, total_score)

    if os.path.exists(log_file):
        f = open(log_file, encoding='utf-8', mode='r')
        m = f.read()
        f.close()
        print('run_grader: grader (%s) log file'%P['grader'])
        print(m)
        print("\n\n")


    # Print score text (must at the end)
    #print(score_txt)
    #print('{"scores": {"P1": 5, "P2": 5},"scoreboard":[5, 5, 10]}')
    return score_txt

if __name__ == '__main__':
    directive = "./answers/ans.txt"
    runpref = '' # prefix must not have space
    runsuff = ''
    grader_paths = {'student': './student',
             'answer': './answers',
             'working': '.',
             'log_file': './glog.txt',
             'student_email_json': './settings.json',
             'student_vfile': './student/verify.txt'}


    scores = run_grader(directive,
        runpref, runsuff, grader_paths)
    print('runtest_tool: main: ', scores)