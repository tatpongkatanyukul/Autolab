"""
Predecessor: mm_grader_center.py, grader_center2.py, grader_center3.py
Created: Dec 27th, 2020.
For:
(1) accommodating C++ (compilation and run)
(2) refactoring code
(3) allowing easier debugging
(4) allowing explanation option
(5) allowing  flexible runtest command

==================================================
Take over control from driver.sh
Assuming
1. student's submission: current directory/student (see paths if change)
    It copies only "target" files to its working directory to grade.
    (This is to safeguard against accident write over grader files.)
    The "target" files are specified in the directive file, e.g., ans.txt.
2. sys.argv[1]: a directive file indicating:
Problem #: Points; Student Submission File; Run File; Test Case in, ans;
3. Three MODES: Autolab (main), Test (single test on PC),
    Local Batch (back up when Autolab server gets stuck).
    Local Batch takes tar files.
4. Identity verification option
    (through secret code defined in secret function)
    4.1 Run gen_emailcode('email file', 'output_email_code_file')
        to get the email-code pairs.
        See D:\Classes\00FCP\2019b\L00a\local_autograde\sandbox1 for example.
        E.g., gen_emailcode('email_list.txt', 'emailcode.txt')
    4.2 Hand codes to students.
    4.3 Ask students to put code in code file, e.g., code.txt.
    4.4 Include code.txt in the tar file
"""

import os
import sys
import tarfile
import json

# For verifying student's identity
from verify_mod import verify, codebookf, read_student_verf

# For running the submission and getting the output
from runtest_tool import clean_folder, run_grader


if __name__ == '__main__':

    grader_paths = {'student': './student',
             'answer': './answers',
             'working': '.',
             'log_file': './glog.txt',
             'student_email_json': './settings.json',
             'student_vfile': './student/verify.txt'}

    # MODE
    # 'Autolab' for running on Autolab server
    # 'Test' for single submission test (student folder) on PC
    # 'Local Batch' for running downloaded all submissions on PC

    MODE = 'Autolab'      # to deploy on Autolab server
    # MODE = 'Test'           # to test a single submission
    # MODE = 'Local Batch'  # to evaluate students' submission, when autolab fails

    #verified = True # for exam/mocking exam
    verified = False # for exercises/homework

    print('GC: MODE =', MODE)
    print('GC: verified =', verified)

    load_identity = False
    # Identify reflection
    try:
        with open(grader_paths['student_email_json'],
                  encoding='utf-8', mode='r') as f:
            jsontxt = f.read()

        d = json.loads(jsontxt)
        print('GC: identity =', d['user'])

        if verified:
            if not verify(d['user'],
               read_student_verf(grader_paths['student_vfile']),
               codebookf):
                print('Verification failed!')
                print('Verification code does not match!')
                exit(0)

        print('GC:', d['user'], 'is verified.')


    except Exception as e:
        print('GC: identity check: exception:', e)
        if verified:
            print('GC: verifying mode: cannot verify identity')
            exit(0)

    runtest_prefix = ''
    runtest_suffix = ''

    print('GC: run test prefix:', runtest_prefix)
    print('GC: run test suffix:', runtest_suffix)

    print()

    if MODE == 'Autolab':
        directive_file = sys.argv[1]

        # Run grader
        rst = run_grader(directive_file, runtest_prefix, runtest_suffix,
                         grader_paths)

        print(rst)

    elif MODE == 'Test':
        directive_file = "./answers/ans.txt"

        rst = run_grader(directive_file, runtest_prefix, runtest_suffix,
                         grader_paths)

        print(rst)

    elif MODE == 'Local Batch':

        directive_file = "./answers/ans.txt"

        # Grading directory
        tar_dir = './tars'
        untar_dir = grader_paths['student']

        # Graded result file
        grade_file = 'graded_results.txt'

        # List all tar submissions to be graded
        tar_files = os.listdir(tar_dir)
        print('Total', len(tar_files), 'files')


        #######################################################
        # Go through each tar: untar, grade, and save result
        #######################################################

        graded_results = ''

        for f in tar_files:

            sid = f.split('.')[0].strip()

            p = os.path.join(tar_dir, f)
            print(p)

            # Clean the target folder
            clean_folder(untar_dir, confirm=False)

            # Untar
            try:
                zf = tarfile.TarFile(p, 'r')
                zf.extractall(untar_dir)
                zf.close()
            except Exception as e:
                graded_results += sid + ";" + str(e) + '\n'
            else:
                # Untar successful
                # Run grader
                rst = run_grader(directive_file, runtest_prefix, runtest_suffix,
                                 grader_paths)

                graded_results += sid + ";" + str(rst) + '\n'

        print(graded_results)

        with open(grade_file, 'w') as grade_f:
            grade_f.write(graded_results)
