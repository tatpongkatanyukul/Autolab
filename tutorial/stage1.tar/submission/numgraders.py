"""
Predecessor: grading_policy3.py (from LCA 2019)
Crated: Dec 26th, 2020
For: unifying the autograder. This policy handles numerical answers
with specified tolerance.
"""

import re

def find_diff(txt1, txt2):
    pos = -1
    N1 = len(txt1)
    N2 = len(txt2)
    N = N1

    if N1 != N2:
        N = min(N1, N2)
        pos = N + 1

    # Search for difference
    for i in range(N):
        if txt1[i] != txt2[i]:
            pos = i
            break

    alpha1 = (None, -1)
    if pos < N1:
        alpha1 = (txt1[pos], ord(txt1[pos]))

    alpha2 = (None, -1)
    if pos < N2:
        alpha2 = (txt2[pos], ord(txt2[pos]))


    return pos, alpha1, alpha2


def get_number(txt):
    '''
    :param txt: e.g., 'Q1', '23', '25.0', '28j', '30.5j'
    :return:
        None for textual string
        number (without j) for a number
        e.g., 'Q1' -> None, '23' -> 23, '25.0' -> 25.0,
            '28j' -> 28, '30.5j' -> 30.5
    '''
    r = re.match('-?[0-9]+\.?[0-9]*j?', txt)

    found = False
    if r:

        # Found match
        sb, se = r.span(0)

        if se < ( len(txt) ):

            # It does not match to the end, e.g., 152A
            # So, this does not count
            found = False
        else:

            # It matches to the end, e.g., 200 or 150j
            found = True

    return found


def check_answer(txtline1, txtline2, ntol):

    # Text match
    is_matched = (txtline1 == txtline2)
    if is_matched:
        return True

    # Breaking a line to chucks
    TL1 = txtline1.split()
    TL2 = txtline2.split()
    N1 = len(TL1)
    N2 = len(TL2)
    if N1 != N2:
        return False

    # Check every term
    is_matched = True
    for i in range(N1):

        if get_number(TL1[i]) and get_number(TL2[i]):

            # number term
            snum1 = TL1[i]
            snum2 = TL2[i]

            diff = 0

            if snum1[-1] != 'j' and snum2[-1] != 'j':

                # Real numbers
                diff = float(snum1) - float(snum2)

            elif snum1[-1] == 'j' and snum2[-1] == 'j':

                # Imaginary numbers
                diff = float(snum1[:-1]) - float(snum2[:-1])

            else:

                # One is real. Another is imaginary.
                is_matched = False
                break


            if -ntol < diff < ntol:
                continue
            else:
                is_matched = False
                break

        else:

            # Text term
            if TL1[i] == TL2[i]:
                continue
            else:
                is_matched = False
                break

    return is_matched



def numtol_policy(policy, policy_attrib,
                                   test_out, gt_ans,
                                   full_score, Px, log):
    '''
    Grading policy
    partial credit by lines with numerical tolerance'
    '''

    return 0