"""
Sensei Rockies
L000 P8
"""

if __name__ == '__main__':

    n = input("What is your favorite number? ")
    print(n, "is a good number.")
