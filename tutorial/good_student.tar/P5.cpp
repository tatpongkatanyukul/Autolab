/*
Sensei Rocky
631010000
L000 P5
*/

#include <iostream>

using namespace std;

int main()
{
    string name;

    cout << "Name: ";
    cin >> name;
    cout << "Hello, " << name << "." << endl;


    return 0;
}
