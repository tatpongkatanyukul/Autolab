/*
Sensei Rocky
631010000
L000 P4
*/

#include <iostream>

using namespace std;

int main()
{
    cout << "Aloha, fellows. I am really happy." << endl;
    return 0;
}
