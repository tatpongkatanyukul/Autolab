#!/bin/bash

# driver.sh - The simplest autograder we could think of. It checks
#   that students can write a C program that compiles, and then
#   executes with an exit status of zero.
#   Usage: ./driver.sh

# This should be a file I'll run to grade student's program.
# bash ./driver.sh

echo "=========================================="
echo "   driver.sh python3.5 autograder v 2.0"
echo "   Hand over control to python script  "
echo "   (last updated Jan 13th, 2021)       "
echo "=========================================="

echo "Extract submission"
(make clean; make)
status=$?
if [ ${status} -ne 0 ]; then
	echo "Failure: Unable to extract the submission"
	echo "{\"scores\": {\"P1\": 0}}"
	exit
fi

echo "Extraction completed."

echo "Examine answer configuration file"
more ./cfg/ans.cfg
echo

echo "Run python autograder script ..."

# Run python autograder code
# Current directory: autograder
# Student's submission: autograder/student

output=$(python3.5 grader_center4.py "./cfg/ans.cfg")
status=$?
if [ ${status} -ne 0 ]; then
	echo "grader_center4.py fails."
	echo "* return status = ${status}"
	echo "{\"scores\": {\"P1\": 0}}"
else
	echo "grader_center4.py is complete."
	echo "=== grader_center.py output ==="
	echo "${output}"
fi

#The last thing out to the screen must be scores for Autolab in the following format:
#{"scores": {"P1": 10, "P2": 10}, "scoreboard":[10, 10, 20]}

#To test static scores, uncomment the line below.
#echo "{\"scores\": {\"P1\": 10, \"P2\": 10},\"scoreboard\":[10, 10, 20]}"

exit

