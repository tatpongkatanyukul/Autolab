"""
P6. Write function weight_conversion to convert weight in pound to kg.
Note: 1 kg = 2.2 pound.
"""

from P6 import weight_conversion



# [!!! Mark 2 !!!]
# Do not edit below this line.
# ------------------------------------------------

if __name__ == '__main__':
    w = 160
    print('{} pounds = {:.2f} kg'.format(w, weight_conversion(w)))
    w = 300
    print('{} pounds = {:.2f} kg'.format(w, weight_conversion(w)))
    w = 500
    print('{} pounds = {:.2f} kg'.format(w, weight_conversion(w)))
    w = 1500
    print('{} pounds = {:.2f} kg'.format(w, weight_conversion(w)))


    #print('= %.2f kg'%weight_conversion(int(input('Enter # pounds:'))))