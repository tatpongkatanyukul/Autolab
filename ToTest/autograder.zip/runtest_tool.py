"""
Last Major Update: Feb 3rd, 2021 (External policy)
* Add timer (Feb 4th, 2021)
"""

import os
from shutil import copy
import time

# For choosing a grading policy
from graders import grading

from cmd_tool import cmd

import platform
from show_cfgdate import get_fdate

def clean_folder(target_folder, confirm=True):
    print('clean_folder: clean', target_folder)

    if confirm:
        c = input('Confirm cleaning [y|n]:')

        if c != 'y':
            print('clean_folder: cancel cleaning.')
            return

    fs = os.listdir(target_folder)
    for f in fs:
        p = os.path.join(target_folder, f)
        os.remove(p)

    print('clean_folder: cleaning is done.')

def get_Grading_Table(directive_fname):
    Grading_Table = []
    f = open(directive_fname, 'r')
    i = 0
    for line in f:

        ## Allow comment out the line
        if line[0] == '#':
            continue

        if i > 0:
            px, score, student, runtest, runtime, \
            grader, gattrib, report_mode, test_case = line.split('\;')


            clean_tc = test_case
            if clean_tc[-1] == '\n':
                clean_tc = clean_tc[:-1]

            clean_tc = clean_tc.strip()

            d = {'Px':px, 'score': int(score),
                 'student': student.strip(),
                 'runtest': runtest.strip(),
                 'runtime': runtime.strip(),
                 'grader': grader.strip(),
                 'attrib': gattrib.strip(),
                 'report_mode': report_mode.strip(),
                 'test_case': clean_tc.split(',')}

            Grading_Table.append(d)


        i += 1
    f.close()
    return Grading_Table
# end get_Grading_Table

def get_testcase(tc_txt, tcpath):
    if len(tc_txt) < 1:
        return None, None

    tc_input, tc_ans = tc_txt.split(' ')

    # Get input stream (or dummy if program requires none)
    f = open(os.path.join(tcpath, tc_input), 'r')
    input_txt = f.read()
    f.close()

    # Get reference answer
    f = open(os.path.join(tcpath, tc_ans), encoding='utf-8',
             mode='r')
    ref_txt = f.read()
    f.close()

    return input_txt, ref_txt


def run_grader(directive, paths):

    plat = platform.system()
    print('run_grader: ==================================================')
    print('run_grader:   Test on platform:', plat)
    print('run_grader:   with settings:', directive)
    d = get_fdate(directive)
    print('run_grader:        (last mod. ', d, ')', sep='')
    print('run_grader: ==================================================')


    student_path = paths['student']
    answer_path = paths['answer']
    working_path = paths['working']
    log_file = paths['log_file']

    # Clear log_file
    with open(log_file, 'w') as f:
        f.write('')

    # Create Grading Table: get grading details from directive file
    Grading_Table = get_Grading_Table(directive)

    #print(Grading_Table)
    print('run_grader: total grading', len(Grading_Table), 'problems')

    graded = {}
    for P in Grading_Table:
        print('\nrun_grader: on', P['Px'])
        student_submission = os.path.join(student_path, P['student'])
        if os.path.exists(student_submission):
            print('run_grader: * %s is submitted'%P['student'])
            print('run_grader: * tested with "%s" using %s policy (attributes: %s)' % (P['runtest'],
                                                        P['grader'], P['attrib']))
            print('run_grader: * test case(s):', P['test_case'])

            # Copy student_submission to current working directory
            copy(student_submission, working_path)

            point = 0
            tc_score = P['score'] / len(P['test_case'])

            for i, tc in enumerate(P['test_case']):

                istream, ans = get_testcase(tc.strip(), answer_path)

                begintime_runtest = time.time()
                # Run the test
                run_complete, rout = \
                    cmd(P['runtest'],
                        istream, float(P['runtime']))
                endtime_runtest = time.time()
                print('run_grader: @ Time to run test: {:.2f} s.'.format(endtime_runtest - begintime_runtest))

                # Grade result if run_complete
                if run_complete:

                    #======================================
                    # Grade the output against the answer
                    #======================================

                    begintime_grading = time.time()
                    grading_out = grading(P['grader'], P['attrib'],
                                    rout, ans, tc_score,
                                    P['Px'], log_file,
                                    mode=P['report_mode'])
                    endtime_grading = time.time()
                    print('run_grader: @ Time to grade: {:.2f} s.'.format(endtime_grading - begintime_grading))

                    print('run_grader: * grading ', grading_out)
                    point += grading_out

            graded_point = round(point)
            graded[P['Px']] = graded_point

            # Clean up/Remove student file
            print('run_grader: * Done: clean up {}'.format(P['student']))
            print('run grader: * {} score = {}'.format(P['student'], graded_point))
            try:
                os.remove(P['student'])
            except Exception as e:
                print('run_grader: ** clean up fails: ', e)

        else:
            print('run_grader: * %s is NOT submitted' % P['student'])
            graded[P['Px']] = 0
    # end for P in Grading_Table
    print() # have a blank line after finishing all gradings.

    # Last line of printing must be score report
    # print(graded)

    csep = ''
    score_txt = '{"scores": {'
    sboard_txt = ''
    total_score = 0
    for P in Grading_Table:
        score_txt += csep + '"%s": %d'%(P['Px'], graded[P['Px']])
        sboard_txt += csep + '%d'%graded[P['Px']]
        total_score += graded[P['Px']]
        if csep == '':
            csep = ', '

    score_txt += '},"scoreboard":[%s, %d]}'%(sboard_txt, total_score)

    if os.path.exists(log_file):
        f = open(log_file, encoding='utf-8', mode='r')
        m = f.read()
        f.close()
        if len(m) > 0:
            print('run_grader: log file content'%P['grader'])
            print(m)
            print("\n\n")

    return score_txt

if __name__ == '__main__':
    directive = "./cfg/ans.cfg"
    grader_paths = {'student': './student',
             'answer': './answers',
             'working': '.',
             'log_file': './glog.txt',
             'student_email_json': './settings.json',
             'student_vfile': './student/verify.txt'}


    scores = run_grader(directive, grader_paths)
    print('runtest_tool: main: ', scores)