/*
P2. Flow rate.
*/

#include <iostream>

using namespace std;

int main(){
	
	float volume, flow;
	cout << "Volume: ";
	cin >> volume;
	
	flow = volume/60;
	cout << "Flow: " << flow << endl;
	return 0;
}