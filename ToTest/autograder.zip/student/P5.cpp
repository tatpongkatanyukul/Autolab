/*
P5: Waste balance sheet.
*/

#include <iostream>
#include <iomanip>

using namespace std;

int main(){
	
	float waste, cap, total_waste, landm2, landrai, landyear;
	
	cout << "Waste: ";
	cin >> waste; // kg/day/person
	cout << "Cap: ";
	cin >> cap;
	
	total_waste = waste * 70e6;
	landm2 = total_waste/cap;
	
	landrai = landm2/1600;
	
	landyear = landrai * 365;
	
	cout << fixed << setprecision(2);
	cout << "Total waste: " << total_waste << endl;
	cout << "Landfill: " << landrai << endl;
	cout << "Annual land: " << landyear << endl;
	
	return 0;
}