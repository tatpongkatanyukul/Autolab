                    if 'i' in e or 'j' in e:
                        onlyNum = e.strip().replace('i','').replace('j','')
                        
                        try:
                            float(onlyNum)
                        except:
                            return "Can't convert {} to number".format(onlyNum)
                        
                        if i == 0:im += float(onlyNum)
                        else :im -= float(onlyNum)
                    else:
                        onlyNum = e.strip().replace('i','').replace('j','')
                        try:
                            float(onlyNum)
                        except:
                            return "Can't convert {} to number".format(onlyNum)
                        
                        if i == 0:re += float(onlyNum)
                        else :re -= float(onlyNum)