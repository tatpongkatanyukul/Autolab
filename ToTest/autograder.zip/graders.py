"""
Last Major Update: Feb 3rd, 2021 (External policy)
Feb 26th, 2021: add numtol_policy2.
"""

from cmd_tool import cmd # for external policy

from base_policies import numtol_policy, parline_policy, exact_policy
from policy2021 import numtol_policy2

def grading(policy, policy_attrib, test_out, gt_ans,
            full_score, Px, log, mode='Test'):


    # Check file in notepad++ with [view] > [show symbol] > [show all characcters]
    # f = open('debug' + Px + 'out.txt', 'w')
    # f.write(test_out)
    #
    # f = open('debug' + Px + 'gt.txt', 'w')
    # f.write(gt_ans)

    # mode = Test: see details
    # mode = Deploy: no details

    test_score = 0

    if policy == 'numtol':
        # numerical tolerance
        test_score = numtol_policy(test_out, gt_ans, full_score, mode, policy_attrib)

    if policy == 'numtol2':
        # numerical tolerance
        test_score = numtol_policy2(test_out, gt_ans, full_score, mode, policy_attrib)       

    elif policy == 'parline':
        # partial credit by line
        test_score = parline_policy(test_out, gt_ans, full_score, mode)


    elif policy == 'external':
        # external grading policy
        # specified by policy_attrib
        # E.g., policy_attrib = "python extpolicy2.py test.cfg; 5"
        # "test.cfg" could specify test cases or P1ref.cpp or both

        extpolicy, ext_time = policy_attrib.split(";")

        extpolicy_command = extpolicy + \
                            " " + str(full_score) + \
                            " " + mode

        print("grading: resorting to the external policy ...", end='')
        run_complete, rout = \
            cmd(extpolicy_command, "dummy input", float(ext_time))

        if run_complete:
            print("grading: the external policy is complete.")
            routlines = rout.split('\n')
            last = routlines[-1]
            test_score = float(last)

            if mode != 'Deploy':
                print('grading: external details: <begin>')
                print(rout)
                print('grading: external details: <end>')
        else:
            print("grading: cannot complete the external policy.")
            print('grading: external details: <begin>')
            print(rout)
            print('grading: external details: <end>')

    else: # exact match (no partial credit/minimal flexibility)

        test_score = exact_policy(test_out, gt_ans, full_score, mode)

    return test_score


if __name__ == '__main__':
    rst = grading("numtol", "0.01",
    "V1 = 11.999 V",
    "V1 = 12 V",
    10, 'Q1', "log.txt", mode='Test')
    print("rst = ", rst)

    print()
    print("----------------------")
    print(" Test external policy")
    print("----------------------")

    print("P3 (good)")
    rst = grading("external",
        "python extpolicy2.py ./cfg/ext2P3good.cfg; 360",
        "dummy student",
        "dummy reference",
        10, 'P3', "log.txt", 'Deploy')
    print("rst = ", rst)

    print("P3 (bad)")
    rst = grading("external",
        "python extpolicy2.py ./cfg/ext2P3bad.cfg; 360",
        "dummy student",
        "dummy reference",
        10, 'P3', "log.txt", 'Deploy')
    print("rst = ", rst)

    print("P3 (worse)")
    rst = grading("external",
        "python extpolicy2.py ./cfg/ext2P3worse.cfg; 360",
        "dummy student",
        "dummy reference",
        10, 'P3', "log.txt", 'Deploy')
    print("rst = ", rst)

    print("P3 (worst)")
    rst = grading("external",
        "python extpolicy2.py ./cfg/ext2P3worst.cfg; 360",
        "dummy student",
        "dummy reference",
        10, 'P3', "log.txt", 'Test')
    print("rst = ", rst)
